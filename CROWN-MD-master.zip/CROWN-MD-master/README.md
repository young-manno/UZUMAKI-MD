## CROWN-BOT (BETA)

> LE WHATSAPP BOT FRANÇAIS QUI A PLUS DE 200 COMMANDES....

### Important 🔜

> LE BOT EST EN COURS DE DEVELOPPEMENT ALORS SI TU TROUVES UNE ERREUR CONTACTER LES CREATEURS POUR LES INFORMER ET ON VOUS AJOUTERA COMME COLLABORATOR OU SI TU PEUX FIXER UN BUG FAIS LE MOI LES COMMANDES SONT OPEN SOURCE ..

### Annonce 👍😊

> LE BOT EST ANTIBAN NI POUR WHATSAPP NI POUR HEROKU NE VOUS INQUIETEZ PAS VOS COMPTES NE SERONT PAS BANNI .. 👍😌

**Creator / Group** : [ANDY MRLIT](https://wa.me/13092208152) / [GROUP](https://chat.whatsapp.com/F3yhzMx25SWF50fBFfc55D)

### Requirements

- [x] NodeJS >= 14
- [x] FFMPEG
- [x] Server vCPU/RAM 1/2GB (Min)

**Notes** :
+ ```ram_limit``` : limite d'utilisation de la RAM, par exemple, vous avez un serveur avec 1 Go de RAM défini avant que la capacité maximale ne soit de 900 Mo.

+ ```DATABASE_URL``` : si tu veux que ton bot enregistre les données automatiquement

### Détection de spam de haut niveau

Ce programme est équipé d'un détecteur de spam (anti-spam) très sensible ce qui va aider a ne pas bannir ton compte WhatsApp 

### Exécuter sur Heroku

Pour exécuter ce bot sur Heroku, il vous suffit de remplir les champs demander et de choisir la région UE (EUROPE) pour votre application :

### Pairing Code

Connexion du compte sans scan QR mais en utilisant le code d'appairage.

Dans le Champ de (Bot number) Tu vas ajouter le numero que tu souhaite ajouter le bot et apres tu rempli les autres champs et après tu clique sur deployer et apres tu cliques sur manage apps et a a droite de tu vas voir *MORE* Tu cliques sur et après tu cliques sur views logs tu vas voir le code tu as juste a ajouter et dans ton compte whatsapp et le bot sera connecter voici quelque exemples :

POUR ALLER SUR MORE ET CLIQUE VIEWS LOGS :

<p align="center"><img align="center" width="100%" src="https://telegra.ph/file/0c11420d30ee7a0ea8d3d.jpg" /></p>

ET AJOUTE CE CODE DANS APPAREILS CONNECTER

<p align="center"><img align="center" width="100%" src="https://telegra.ph/file/0a2380f6fcf4bba4ae89b.jpg" /></p>

#### Setup
- [FORK](https://github.com/mrlit-a/crown-md/fork) this repository.
- Inscrivez-vous et créez un compte Heroku [here](https://signup.heroku.com)
- After login, click the below **Deploy** button.

   [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://gitredirec.vercel.app/)
 
 - Donnez un nom à votre application `<your_app_name>` et rempli les autres champs et tu cliques sur `Deploy app` button.
 - Ça devrait prendre 5-10 minutes. 
 - Une fois terminé, Click `manage app` et apres tu cliques sur `<more> et tu cliques sur views logs et tu ajoutes le pairing code sur ton whatsapp le bot sera connecter`.

```Javascript

### QUELQUES COMMANDES QUI POURRAIENT ÊTRE UTILE :

+ ```.+owner``` : pour ajouter une autre numero comme proprietaire 

+ ```changemenu``` : pour changer le style de menu 

+ ```modegroupe``` : le commande sera fonctionnelle seulement en groupe 

+ ```prive``` : pour que le bot fonctionne seulement en privé

+ ```.+prem``` : pour ajouter une personne comme utilisateurs premium 

+ ```autotelechargement``` : pour que le bot telecharge des videos ou photos automatiquent sur ytb, tiktok, ig, ytb juste avec le lien sans faire de commande tu vas juste envoyer au bot et il telecharge

+ ```lenomdubot``` : pour changer le nom du bot

+ ```play ou jouer``` : pour telecharger des videos ou musiques sur youtube..

Pour les autres, veuillez apprendre par vous-même à partir d'autres plugins

Consultez régulièrement ce repo pour obtenir des mises à jour car la base de progression n'est pas à 100 % a jour (il s'agit simplement d'un test de base ou bêta), si vous trouvez une erreur, veuillez signaler un problème. Merci.
      
 
 href="https://github.com/mrlit-a/crown-md/issues">Report Bug</a>
 
 ### Thanks To

- [MRLIT ANDY](https://github.com/andymrlit) for [Plugins](https://github.com/andymrlit)

- [@adiwajshing](https://github.com/adiwajshing) for [Baileys](https://github.com/adiwajshing/Baileys)

[FARADA](https://github.com/Farada17) pour ["m'avoir aider a realiser ce projet"](https://github.com/Farada17)

[RAZA](https://github.com/IndYorrichi) pour ["m'avoir aider a creer les fichiers"](https://github.com/IndYorrichi)    
